
package aulajdbc;

import java.sql.*; //importar toda bibi JDBC

import java.util.logging.Level;
import java.util.logging.Logger;


public class AulaJDBC {

    //Objetos "globais"
    static Connection con;
    static Statement stmt;
    static ResultSet rs;
    
    public static void main(String[] args) throws SQLException {
        String url;
        
        try {
            
            //1. Carregar o driver do MySQL
            Class.forName("com.mysql.jdbc.Driver");
            //2. URL do banco de dados
            url = "jdbc:mysql://localhost:3306/clinica";
            //3. Estabeler a conexão com o BD
            con = DriverManager.getConnection(url, "root", null);
            //4. Consultar dados no BD
            stmt = con.createStatement();
            //5. Executar a consulta
            rs = stmt.executeQuery("select * from medicos");
            //6. Processar resultado
            while(rs.next()){
                System.out.println("Nome: " + rs.getString("nome"));
                System.out.println("Especialidade: " + rs.getString("especialidade"));
            }
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AulaJDBC.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(AulaJDBC.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally{
            //7. fechar conexões
            stmt.close();
            rs.close();
            con.close();
        }
    }
    
}
