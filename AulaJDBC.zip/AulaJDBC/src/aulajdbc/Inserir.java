
package aulajdbc;

import com.mysql.jdbc.exceptions.jdbc4.*;
import java.sql.*;

import java.util.logging.Level;
import java.util.logging.Logger;


public class Inserir {
    
    public static void main(String[] args) {
        
        String url;
        
        try {
            //1. Carregar o driver do MySQL
            Class.forName("com.mysql.jdbc.Driver");
            //2. URL do banco de dados
            url = "jdbc:mysql://localhost:3306/clinica";
            //3. Estabeler a conexão com o BD
            Connection con = DriverManager.getConnection(url, "root", null);
            //4. Inserir dados no BD
            Statement stmt = con.createStatement(); 
            //5. Executar a consulta
            int resp = stmt.executeUpdate("insert into medicos" + 
                                          " (codm, nome, idade)" + 
                                          " values(5, 'Marcia', 33);");
            if (resp > 0 ){
                System.out.println("Médico cadastrado com sucesso!");
            }
            //6. fechar conexões
            stmt.close();
            con.close();
        
        }catch (MySQLIntegrityConstraintViolationException e1){
            System.out.println("Médico já cadastrado no sistema!");
        }
        catch (ClassNotFoundException e2) {
            Logger.getLogger(Inserir.class.getName()).log(Level.SEVERE, null, e2);
        } 
        catch (SQLException e3) {
            Logger.getLogger(Inserir.class.getName()).log(Level.SEVERE, null, e3);
        } 
    }
}