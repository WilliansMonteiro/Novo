package DAO;

import java.sql.DriverManager;
import java.sql.SQLException;
import com.mysql.jdbc.Connection;

/**
 *
 * @author affonso
 */
public class Conexao {
 
  private String driver = "com.mysql.jdbc.Driver";
  private String URL = "jdbc:mysql://localhost:3306/VENDADB";
  private String USER = "root";
  private String PASS = "root";
  private Connection conn;

  public Conexao() throws SQLException, ClassNotFoundException{
        
    try{
      Class.forName(driver);
      conn = (Connection) DriverManager.getConnection(URL,USER,PASS);
    }catch (SQLException | ClassNotFoundException e) {
      throw e;
    }
  }

  public Connection getConn(){
    return conn;    
  }

  public void fecharConexao() throws SQLException{
    try {
      conn.close();
    }catch (SQLException e){
      throw e;
    }
  }
  
  public void commit() throws SQLException{
      try {
      conn.commit();
    }catch (SQLException e){
      throw e;
    }
  }
  
  public void rollback() throws SQLException{
      try {
      conn.rollback();
    }catch (SQLException e){
      throw e;
    }
  }
  
  public void autoCommit(Boolean option)throws SQLException{
      try {
      conn.setAutoCommit(option);
      }catch (SQLException e){
      throw e;
    }
  }
}
