package cadmed;

import java.util.Scanner;

public class CadMed {
    
    static Scanner tecla = new Scanner(System.in);
    
    public static void main(String[] args) {
        int op;
        do {                
            System.out.println("*** MENU PRINCIPAL ***");
            System.out.println("1-Incluir médicos");
            System.out.println("2-Excluir médicos");
            System.out.println("3-Alterar médicos");
            System.out.println("4-Lista todos os médicos");
            System.out.println("5-Sair");
            System.out.println("Digite sua opção: ");
            op = tecla.nextInt(); 
            switch(op){
                case 1: incluir(); break;
                case 2: excluir(); break;
                case 3: alterar(); break;
                case 4: listar(); break;
                case 5: break;
            }
        } while (op!=5);
    }
    
    private static void incluir(){
        //Entrada de dados
        System.out.println("Código:");
        int cod = tecla.nextInt();
        System.out.println("Nome:");
        String nome = tecla.next();
        System.out.println("Idade:");
        int idade = tecla.nextInt();
        System.out.println("Especialidade:");
        String esp = tecla.next();
        System.out.println("CPF:");
        int cpf = tecla.nextInt();
        System.out.println("Cidade:");
        String cidade = tecla.next();
        
        //criar o objeto
        Medico med = new Medico(cod, nome, idade, esp, cpf, cidade);
        
        //incluir
        if (med.incluir() > 0) {
            System.out.println("Médico cadastrado com sucesso!");
        }
    }
    
    private static void excluir(){
        //Entrada de dados
        System.out.println("Código:");
        int cod = tecla.nextInt();
        //criar o objeto
        Medico med = new Medico(cod);
        //excluir
        if (med.excluir() > 0){
            System.out.println("Médico excluído com sucesso!");
        }
    }
    
    private static void alterar(){
        //Entrada de dados
        System.out.println("Código:");
        int cod = tecla.nextInt();
        
        //Exibir os dados para alteração
        Medico med = new Medico(cod);
        med.listar(cod);
        
        //Entrada de dados
        System.out.println("Nome:");
        String nome = tecla.next();
        System.out.println("Idade:");
        int idade = tecla.nextInt();
        System.out.println("Especialidade:");
        String esp = tecla.next();
        System.out.println("CPF:");
        int cpf = tecla.nextInt();
        System.out.println("Cidade:");
        String cidade = tecla.next();
        
        //Set
        med.setNome(nome);
        
        //alterar
        if (med.alterar() > 0) {
            System.out.println("Médico alterado com sucesso!");
        }
        
    }
    
    private static void listar(){
    
    }
}