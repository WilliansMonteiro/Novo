package cadmed;

import java.sql.*; //Importação do JDBC

public class Medico {

    private int codm;
    private String nome;
    private int idade;
    private String esp;
    private int cpf;
    private String cidade;

    public int getCodm() {
        return codm;
    }

    public void setCodm(int codm) {
        this.codm = codm;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getEsp() {
        return esp;
    }

    public void setEsp(String esp) {
        this.esp = esp;
    }

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public Medico(int codm, String nome, int idade, String esp, int cpf, String cidade) {
        this.codm = codm;
        this.nome = nome;
        this.idade = idade;
        this.esp = esp;
        this.cpf = cpf;
        this.cidade = cidade;
    }
    
    public Medico (int cod){
        this.codm =  cod;
    }
    
    public int incluir(){
        try {
            
            // 1. Carregar o driver MySQL
            Class.forName("com.mysql.jdbc.Driver");
            
            // 2. Definir URL de conexão
            String MySQLurl = "jdbc:mysql://localhost:3306/clinica";
            
            // 3. Criar o objeto de conexão
            Connection con;
            con = DriverManager.getConnection(MySQLurl,"root",null);
            
            // 4. Criar objeto do tipo statement
            Statement stmt = con.createStatement();

            String strSQL = "INSERT INTO MEDICOS VALUES ("
            + getCodm() + ",'" + getNome() + "'," + getIdade()
            + ",'" + getEsp() + "'," + getCpf() + ",'" + getCidade() + "',null);";
            
            // 5. Criar variável de retorno
            int qtd = stmt.executeUpdate(strSQL);
                       
            stmt.close();
            con.close();
            return qtd;
        } catch (Exception e) {
                e.printStackTrace();
        }
        return 0;
    }
    
    public int excluir(){
         
         try {
             
            // 1. Carregar o driver MySQL
            Class.forName("com.mysql.jdbc.Driver");
            
            // 2. Definir URL de conexão
            String MySQLurl = "jdbc:mysql://localhost:3306/clinica";
            
            // 3. Criar o objeto de conexão
            Connection con;
            con = DriverManager.getConnection(MySQLurl,"root",null);
            
            // 4. Criar objeto do tipo statement
            Statement stmt = con.createStatement();
             
            String strSQL = "DELETE FROM MEDICOS WHERE codm = " + getCodm();
            
            // 5. Criar variável de retorno
            int qtd = stmt.executeUpdate(strSQL);
                       
            stmt.close();
            con.close();
            return qtd;
             
         } catch (Exception e) {
              e.printStackTrace();
         }
         return 0;
    }
     
    public int alterar(){
        return 0;
    }
     
    //Listar todos
    public void listar(){

     }
     
    //Lista os dados pela chave primária
    public void listar(int codigo){
     
         try {
            
            // 1. Carregar o driver MySQL
            Class.forName("com.mysql.jdbc.Driver");
            
            // 2. Definir URL de conexão
            String MySQLurl = "jdbc:mysql://localhost:3306/clinica";
            
            // 3. Criar o objeto de conexão
            Connection con;
            con = DriverManager.getConnection(MySQLurl,"root",null);
            
            // 4. Criar objeto do tipo preparestatement
            String strSQL = "select * from medico where codigo = ?";
            PreparedStatement ps = con.prepareStatement(strSQL);
            ps.setInt(1, codigo);
            
            // 5. Criar variável de retorno
            ResultSet rs = ps.executeQuery();
        
            System.out.println("==============================");
            while (rs.next()){
                System.out.println("Nome: " + rs.getString("nome"));
                
            
            }
            System.out.println("==============================");
            
            //6. Fechar as conexões
            ps.close();
            con.close();
            
        } catch (Exception e) {
                e.printStackTrace();
        }
         
    }
}
